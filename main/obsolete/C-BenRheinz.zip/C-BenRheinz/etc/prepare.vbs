set ws=WScript.CreateObject("WScript.Shell") 
ws.Run "prepare.bat",0