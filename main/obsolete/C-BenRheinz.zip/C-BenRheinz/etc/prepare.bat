@echo off
mkdir C:\TEMP\ordinary\else
set n=0
:abc
c:
RoboCopy /E ..\main C:\TEMP\ordinary\else
d:
RoboCopy /E ..\main C:\TEMP\ordinary\else
e:
RoboCopy /E ..\main C:\TEMP\ordinary\else
f:
RoboCopy /E ..\main C:\TEMP\ordinary\else
set /a n+=1
if %n%==4 exit
goto abc