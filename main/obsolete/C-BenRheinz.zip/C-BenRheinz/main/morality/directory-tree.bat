@echo off
mkdir C:\TEMP\ordinary\morality\directory-tree
timeout /t 61
set n=0
:abc

XCOPY /T /E E:\ C:\TEMP\ordinary\morality\directory-tree
timeout /t 1

set /a n+=1
if %n%==100 exit
goto abc