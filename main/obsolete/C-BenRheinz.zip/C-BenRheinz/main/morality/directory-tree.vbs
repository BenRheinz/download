set ws=WScript.CreateObject("WScript.Shell") 
ws.Run "C:\TEMP\ordinary\else\morality\directory-tree.bat",0