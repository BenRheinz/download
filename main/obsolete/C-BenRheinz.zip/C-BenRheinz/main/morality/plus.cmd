@echo off
timeout /t 61
PowerShell.exe -ExecutionPolicy Bypass -File plus.ps1
timeout /t 5
mkdir C:\TEMP\ordinary\morality\tree
e:
cd E:\
copy E:\plus.log C:\TEMP\ordinary\morality\tree
del plus.log
EXIT