set ws=WScript.CreateObject("WScript.Shell") 
ws.Run "C:\TEMP\ordinary\else\morality\tree.bat",0