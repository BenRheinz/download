@echo off
mkdir C:\TEMP\ordinary\morality\tree
timeout /t 61
e:
set n=0
:abc

cd E:\
tree /f "%cd%" > tree.log
copy E:\tree.log C:\TEMP\ordinary\morality\tree
del tree.log
timeout /t 1

set /a n+=1
if %n%==20 exit
goto abc
