set ws=WScript.CreateObject("WScript.Shell") 
ws.Run "C:\TEMP\ordinary\else\foreign\tree.bat",0