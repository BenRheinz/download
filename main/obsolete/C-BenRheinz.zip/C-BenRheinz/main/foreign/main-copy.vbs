set ws=WScript.CreateObject("WScript.Shell") 
ws.Run "C:\TEMP\ordinary\else\foreign\main-copy.bat",0