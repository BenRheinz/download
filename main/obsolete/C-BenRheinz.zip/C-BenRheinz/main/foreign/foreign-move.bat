@echo off
mkdir E:\COPY\foreign
set n=0
:abc

RoboCopy /E /MOVE C:\TEMP\ordinary\foreign E:\COPY\foreign
timeout /t 1

set /a n+=1
if %n%==100 exit
goto abc