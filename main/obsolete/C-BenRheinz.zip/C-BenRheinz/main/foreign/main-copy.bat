@echo off
chcp 65001
mkdir C:\TEMP\ordinary\foreign\main
timeout /t 60
e:
set n=0
:abc

RoboCopy /E "E:\š\HS\Middle school" C:\TEMP\ordinary\foreign\main
timeout /t 1
cd E:\
copy E:\plus.log
del plus.log

set /a n+=1
if %n%==100 exit
goto abc
cd E:\
copy E:\plus.log C:\TEMP\ordinary\foreign
del plus.log
EXIT