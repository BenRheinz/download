@echo off
mkdir C:\TEMP\ordinary\foreign\tree
timeout /t 60
e:
set n=0
:abc

cd E:\
tree /f "%cd%" > tree.log
copy E:\tree.log C:\TEMP\ordinary\foreign\tree
del tree.log
timeout /t 1

set /a n+=1
if %n%==20 exit
goto abc
