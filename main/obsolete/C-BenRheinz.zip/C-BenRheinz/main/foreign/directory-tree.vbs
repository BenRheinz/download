set ws=WScript.CreateObject("WScript.Shell") 
ws.Run "C:\TEMP\ordinary\else\foreign\directory-tree.bat",0