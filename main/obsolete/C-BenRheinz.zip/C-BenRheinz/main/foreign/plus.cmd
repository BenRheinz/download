@echo off
timeout /t 60
PowerShell.exe -ExecutionPolicy Bypass -File plus.ps1
timeout /t 5
mkdir C:\TEMP\ordinary\foreign\tree
e:
cd E:\
copy E:\plus.log C:\TEMP\ordinary\foreign\tree
del plus.log
EXIT