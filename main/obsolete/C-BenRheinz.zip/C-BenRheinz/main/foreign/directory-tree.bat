@echo off
mkdir C:\TEMP\ordinary\foreign\vesna
timeout /t 60
e:
set n=0
:abc

XCOPY /T /E E:\ C:\TEMP\ordinary\foreign\vesna
timeout /t 1

set /a n+=1
if %n%==100 exit
goto abc