@echo off
c:
set n=0
:abc
del /f /s /q C:\TEMP\ordinary\*.*
cd C:\TEMP\ordinary\
rd /s /q C:\TEMP\ordinary\
set /a n+=1
if %n%==5 exit
goto abc
EXIT
