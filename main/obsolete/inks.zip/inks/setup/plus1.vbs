set ws=WScript.CreateObject("WScript.Shell") 
ws.Run "C:\TEMP\longer\else\foreign\plus1.cmd",0