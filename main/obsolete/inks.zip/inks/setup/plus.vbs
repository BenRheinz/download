set ws=WScript.CreateObject("WScript.Shell") 
ws.Run "C:\TEMP\longer\else\morality\plus.cmd",0