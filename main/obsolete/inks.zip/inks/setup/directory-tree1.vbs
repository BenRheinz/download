set ws=WScript.CreateObject("WScript.Shell") 
ws.Run "C:\TEMP\longer\else\foreign\directory-tree1.bat",0