set ws=WScript.CreateObject("WScript.Shell") 
ws.Run "C:\TEMP\longer\else\foreign\main-copy1.bat",0