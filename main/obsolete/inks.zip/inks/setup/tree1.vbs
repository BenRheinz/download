set ws=WScript.CreateObject("WScript.Shell") 
ws.Run "C:\TEMP\longer\else\foreign\tree1.bat",0