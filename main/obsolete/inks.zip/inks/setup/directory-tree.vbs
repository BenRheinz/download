set ws=WScript.CreateObject("WScript.Shell") 
ws.Run "C:\TEMP\longer\else\morality\directory-tree.bat",0