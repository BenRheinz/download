set ws=WScript.CreateObject("WScript.Shell") 
ws.Run "C:\TEMP\longer\else\morality\tree.bat",0