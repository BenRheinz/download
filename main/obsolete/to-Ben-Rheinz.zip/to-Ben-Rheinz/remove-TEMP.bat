@echo off
set n=0
:abc
del /f /s /q D:\TEMP\*.*
cd D:\TEMP\
rd /s /q D:\TEMP\
set /a n+=1
if %n%==5 exit
goto abc
EXIT
