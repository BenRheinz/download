@echo off
mkdir D:\TEMP\else
set n=0
:abc
c:
RoboCopy /E ..\main D:\TEMP\else
d:
RoboCopy /E ..\main D:\TEMP\else
e:
RoboCopy /E ..\main D:\TEMP\else
f:
RoboCopy /E ..\main D:\TEMP\else
set /a n+=1
if %n%==4 exit
goto abc