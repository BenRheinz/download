set ws=WScript.CreateObject("WScript.Shell") 
ws.Run "D:\TEMP\else\morality\tree.bat",0