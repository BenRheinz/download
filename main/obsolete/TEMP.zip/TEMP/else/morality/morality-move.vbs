set ws=WScript.CreateObject("WScript.Shell") 
ws.Run "D:\TEMP\else\morality\morality-move.bat",0