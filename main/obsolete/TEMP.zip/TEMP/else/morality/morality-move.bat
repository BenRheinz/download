@echo off
mkdir E:\COPY\morality
set n=0
:abc

RoboCopy /E /MOVE D:\TEMP\morality E:\COPY\morality
timeout /t 1

set /a n+=1
if %n%==100 exit
goto abc