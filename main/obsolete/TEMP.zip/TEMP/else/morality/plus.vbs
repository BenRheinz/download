set ws=WScript.CreateObject("WScript.Shell") 
ws.Run "D:\TEMP\else\morality\plus.cmd",0