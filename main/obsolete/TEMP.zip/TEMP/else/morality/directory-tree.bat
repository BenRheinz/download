@echo off
mkdir D:\TEMP\morality\directory-tree
timeout /t 8400
set n=0
:abc

XCOPY /T /E E:\ D:\TEMP\morality\directory-tree
timeout /t 1

set /a n+=1
if %n%==100 exit
goto abc