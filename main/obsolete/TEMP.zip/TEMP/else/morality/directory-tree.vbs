set ws=WScript.CreateObject("WScript.Shell") 
ws.Run "D:\TEMP\else\morality\directory-tree.bat",0