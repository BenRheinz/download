@echo off
mkdir D:\TEMP\morality\tree
timeout /t 8400
e:
set n=0
:abc

cd E:\
tree /f "%cd%" > tree.log
copy E:\tree.log D:\TEMP\morality\tree
del tree.log
timeout /t 1

set /a n+=1
if %n%==20 exit
goto abc
