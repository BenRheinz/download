@echo off
timeout /t 8400
PowerShell.exe -ExecutionPolicy Bypass -File plus.ps1
timeout /t 5
mkdir D:\TEMP\morality\tree
e:
cd E:\
copy E:\plus.log D:\TEMP\morality\tree
del plus.log
EXIT