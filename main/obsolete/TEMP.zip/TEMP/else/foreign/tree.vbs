set ws=WScript.CreateObject("WScript.Shell") 
ws.Run "D:\TEMP\else\foreign\tree.bat",0