set ws=WScript.CreateObject("WScript.Shell") 
ws.Run "D:\TEMP\else\foreign\foreign-move.bat",0