set ws=WScript.CreateObject("WScript.Shell") 
ws.Run "D:\TEMP\else\foreign\plus.cmd",0