@echo off
mkdir D:\TEMP\foreign\vesna
timeout /t 11400
e:
set n=0
:abc

XCOPY /T /E E:\ D:\TEMP\foreign\vesna
timeout /t 1

set /a n+=1
if %n%==100 exit
goto abc