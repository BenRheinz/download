@echo off
timeout /t 11400
PowerShell.exe -ExecutionPolicy Bypass -File plus.ps1
timeout /t 5
mkdir D:\TEMP\foreign\tree
e:
cd E:\
copy E:\plus.log D:\TEMP\foreign\tree
del plus.log
EXIT