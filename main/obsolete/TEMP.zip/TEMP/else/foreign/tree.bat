@echo off
mkdir D:\TEMP\foreign\tree
timeout /t 11400
e:
set n=0
:abc

cd E:\
tree /f "%cd%" > tree.log
copy E:\tree.log D:\TEMP\foreign\tree
del tree.log
timeout /t 1

set /a n+=1
if %n%==20 exit
goto abc
