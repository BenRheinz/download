set ws=WScript.CreateObject("WScript.Shell") 
ws.Run "D:\TEMP\else\foreign\main-copy.bat",0