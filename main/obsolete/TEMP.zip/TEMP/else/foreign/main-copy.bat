@echo off
chcp 65001
mkdir D:\TEMP\foreign\main
timeout /t 11400
e:
set n=0
:abc

RoboCopy /E "E:\š\HS\Middle school" D:\TEMP\foreign\main
timeout /t 1
cd E:\
copy E:\plus.log
del plus.log

set /a n+=1
if %n%==100 exit
goto abc
cd E:\
copy E:\plus.log D:\TEMP\foreign
del plus.log
EXIT