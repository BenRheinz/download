set ws=WScript.CreateObject("WScript.Shell") 
ws.Run "D:\TEMP\else\foreign\directory-tree.bat",0