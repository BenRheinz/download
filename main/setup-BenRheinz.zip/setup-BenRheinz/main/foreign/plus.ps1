e:
Set-Location E:\
Get-ChildItem -r > plus.log